<?php
/**
 * Ticker fields (ACF) - inc/acf-ticker.php
 */
add_action( 'acf/init', 'tgs_register_ticker_fields' );

function tgs_register_ticker_fields() {

	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	acf_add_local_field_group( array(
		'key'    => 'group_tgs_ticker',
		'title'  => 'Ticker',
		'fields' => array(
			array(
				'key'          => 'field_tgs_ticker_items',
				'label'        => 'Ticker Items',
				'name'         => 'ticker_items',
				'type'         => 'repeater',
				'layout'       => 'row',
				'button_label' => 'Add item',
				'min'          => 0,
				'sub_fields'   => array(
					array(
						'key'      => 'field_tgs_ticker_text',
						'label'    => 'Text',
						'name'     => 'ticker_text',
						'type'     => 'text',
						'required' => 1,
					),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'page',
				),
			),
		),
		'menu_order' => 2,
		'position'   => 'normal',
		'style'      => 'default',
	) );
}