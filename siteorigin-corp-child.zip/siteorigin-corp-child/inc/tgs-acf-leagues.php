<?php
/**
 * ACF field group: TGS – Leagues page
 * functions.php mein:  require_once get_stylesheet_directory() . '/inc/tgs-acf-leagues.php';
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }

	acf_add_local_field_group( array(
		'key'    => 'group_tgs_leagues_page',
		'title'  => 'TGS – Leagues Page',
		'fields' => array(
			array(
				'key'        => 'field_tgs_leagues',
				'label'      => 'Golf Leagues section',
				'name'       => 'leagues',
				'type'       => 'group',
				'layout'     => 'block',
				'sub_fields' => array(
					array(
						'key' => 'field_tgs_leagues_eyebrow', 'label' => 'Small label (eyebrow)', 'name' => 'eyebrow',
						'type' => 'text', 'default_value' => 'Starting in February',
						'wrapper' => array( 'width' => '50', 'class' => '', 'id' => '' ),
					),
					array(
						'key' => 'field_tgs_leagues_title', 'label' => 'Heading (H1)', 'name' => 'title',
						'type' => 'text', 'default_value' => 'Golf Leagues',
						'wrapper' => array( 'width' => '50', 'class' => '', 'id' => '' ),
					),
					array(
						'key' => 'field_tgs_leagues_intro', 'label' => 'Intro text', 'name' => 'intro',
						'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'basic', 'media_upload' => 0, 'delay' => 1,
						'default_value' => '<p>Our Golf Leagues will start in February and will have some of the best prizes available in Australia. There will be various golf leagues for both men and women including Individual, 2 Person Teams and 3 Person Teams. Please register your interest below and we will be in touch in January.</p>',
					),
					array(
						'key' => 'field_tgs_leagues_button_text', 'label' => 'Button text', 'name' => 'button_text',
						'type' => 'text', 'default_value' => 'Register Interest Now',
						'wrapper' => array( 'width' => '50', 'class' => '', 'id' => '' ),
					),
					array(
						'key' => 'field_tgs_leagues_form_title', 'label' => 'Popup heading', 'name' => 'form_title',
						'type' => 'text', 'default_value' => 'Register your interest',
						'wrapper' => array( 'width' => '50', 'class' => '', 'id' => '' ),
					),
					array(
						'key' => 'field_tgs_leagues_form_intro', 'label' => 'Popup small text (optional)', 'name' => 'form_intro',
						'type' => 'textarea', 'rows' => 2, 'new_lines' => '',
						'default_value' => 'Fill in your details and we will be in touch in January.',
					),
					array(
						'key' => 'field_tgs_leagues_form_shortcode', 'label' => 'Form shortcode', 'name' => 'form_shortcode',
						'type' => 'text',
						'instructions' => 'Contact Form 7 ka shortcode yahan paste karein, jaise: [contact-form-7 id="1234" title="League interest"]',
					),
					array(
						'key' => 'field_tgs_leagues_types', 'label' => 'League types (optional)', 'name' => 'types',
						'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Add league type',
						'instructions' => 'Individual, 2 Person Teams, 3 Person Teams jaise chhote cards. Khali chhodein to section nahi dikhega.',
						'sub_fields' => array(
							array( 'key' => 'field_tgs_leagues_types_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text', 'required' => 1, 'wrapper' => array( 'width' => '35', 'class' => '', 'id' => '' ) ),
							array( 'key' => 'field_tgs_leagues_types_text', 'label' => 'Short text', 'name' => 'text', 'type' => 'text', 'wrapper' => array( 'width' => '65', 'class' => '', 'id' => '' ) ),
						),
					),
					array(
						'key' => 'field_tgs_leagues_extra', 'label' => 'Extra content below (optional)', 'name' => 'extra',
						'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'basic', 'media_upload' => 0, 'delay' => 1,
					),
				),
			),
		),
		'location' => array(
			array(
				array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-tgs-leagues.php' ),
			),
		),
		'position'              => 'normal',
		'style'                 => 'seamless',
		'label_placement'       => 'top',
		'instruction_placement' => 'label',
		'active'                => true,
	) );
} );
