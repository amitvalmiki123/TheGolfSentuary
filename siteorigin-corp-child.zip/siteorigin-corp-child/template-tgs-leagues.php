<?php
/**
 * Template Name: TGS Leagues
 * Template Post Type: page
 *
 * Fields: ACF group "TGS – Leagues Page" (inc/tgs-acf-leagues.php)
 */
get_header( 'home' );

$lg        = tgs_field( 'leagues' );
$title     = $lg['title'] ?? get_the_title();
$btn_text  = ! empty( $lg['button_text'] ) ? $lg['button_text'] : 'Register Interest Now';
$shortcode = $lg['form_shortcode'] ?? '';
?>

<main id="main" class="lg-page">

	<section class="lg-intro" aria-labelledby="lg-title">
		<div class="wrap lg-intro-inner">
			<?php if ( ! empty( $lg['eyebrow'] ) ) : ?><p class="eyebrow"><?php echo esc_html( $lg['eyebrow'] ); ?></p><?php endif; ?>
			<h1 class="h2 lg-title" id="lg-title"><?php echo esc_html( $title ); ?></h1>

			<?php if ( ! empty( $lg['intro'] ) ) : ?>
			<div class="lg-text"><?php echo wp_kses_post( $lg['intro'] ); ?></div>
			<?php endif; ?>

			<?php if ( $shortcode ) : ?>
			<button class="btn btn--primary btn--lg" type="button" aria-haspopup="dialog" data-lg-open>
				<?php echo esc_html( $btn_text ); ?> <?php echo tgs_icon( 'arrow' ); ?>
			</button>
			<?php endif; ?>
		</div>
	</section>

	<?php if ( ! empty( $lg['types'] ) ) : ?>
	<section class="lg-types" aria-label="League types">
		<div class="wrap">
			<ul class="lg-types-grid">
				<?php foreach ( $lg['types'] as $t ) : ?>
				<li class="lg-type">
					<h2 class="lg-type-title"><?php echo esc_html( $t['title'] ); ?></h2>
					<?php if ( ! empty( $t['text'] ) ) : ?><p><?php echo esc_html( $t['text'] ); ?></p><?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $lg['extra'] ) ) : ?>
	<section class="lg-extra">
		<div class="wrap lg-extra-inner"><?php echo wp_kses_post( $lg['extra'] ); ?></div>
	</section>
	<?php endif; ?>

</main>

<?php if ( $shortcode ) : ?>
<!-- Registration form popup -->
<dialog class="lg-dialog" id="lg-dialog" aria-labelledby="lg-dialog-title">
	<div class="lg-dialog-card">
		<button class="lg-dialog-close" type="button" aria-label="Close" data-lg-close><?php echo tgs_icon( 'close' ); ?></button>
		<h2 class="lg-dialog-title" id="lg-dialog-title"><?php echo esc_html( $lg['form_title'] ?? 'Register your interest' ); ?></h2>
		<?php if ( ! empty( $lg['form_intro'] ) ) : ?><p class="lg-dialog-intro"><?php echo esc_html( $lg['form_intro'] ); ?></p><?php endif; ?>
		<div class="lg-form"><?php echo do_shortcode( wp_unslash( $shortcode ) ); ?></div>
	</div>
</dialog>

<script>
(function () {
	var dlg = document.getElementById('lg-dialog');
	if (!dlg) { return; }

	function open() {
		if (dlg.open) { return; }
		if (typeof dlg.showModal === 'function') { dlg.showModal(); } else { dlg.setAttribute('open', ''); }
	}
	function close() { if (dlg.open) { dlg.close(); } }

	document.addEventListener('click', function (e) {
		if (e.target.closest('[data-lg-open]')) { e.preventDefault(); open(); return; }
		if (e.target.closest('[data-lg-close]') || e.target === dlg) { close(); }
	});

	// Link se seedha form kholna ho: /leagues/#register
	if (window.location.hash === '#register') { open(); }
})();
</script>
<?php endif; ?>

<?php get_footer( 'home' );
