<?php
/**
 * Helpers + Options page for The Golf Sanctuary theme.
 * Load from functions.php: require_once get_template_directory() . '/inc/tgs-helpers.php';
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------- ACF Options page (Header, Footer & Business) ---------- */
add_action( 'acf/init', function () {
	if ( function_exists( 'acf_add_options_page' ) ) {
		acf_add_options_page( array(
			'page_title' => 'Header, Footer & Business',
			'menu_title' => 'Site Settings',
			'menu_slug'  => 'tgs-site-settings',
			'capability' => 'edit_posts',
			'icon_url'   => 'dashicons-admin-generic',
			'redirect'   => false,
		) );
	}
} );

/* ---------- Field getters (safe even if ACF is inactive) ---------- */
function tgs_field( $name, $post_id = false ) {
	if ( ! function_exists( 'get_field' ) ) { return array(); }
	$v = get_field( $name, $post_id );
	return $v ? $v : array();
}
function tgs_global( $name ) { return tgs_field( $name, 'option' ); }

/* ---------- Small output helpers ---------- */
function tgs_icon( $id ) {
	// Fallback mode: <span> icons drawn by CSS mask (add define('TGS_ICON_MASK', true); in functions.php + tgs-icons.css)
	if ( defined( 'TGS_ICON_MASK' ) && TGS_ICON_MASK ) {
		return '<span class="i i-m i-m--' . esc_attr( $id ) . '" aria-hidden="true"></span>';
	}
	// Inline SVG (no sprite needed) — works even if a plugin strips <use> / the sprite.
	static $paths = null;
	if ( null === $paths ) {
		$paths = array(
		'arrow' => '<path d="M4 12h15M13 6l6 6-6 6"/>',
		'arrow-ne' => '<path d="M7 17 17 7M8.5 7H17v8.5"/>',
		'chevron' => '<path d="m6 9 6 6 6-6"/>',
		'phone' => '<path d="M6.6 3.5h2.6l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5v2.6a2 2 0 0 1-2.2 2A17 17 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2z"/>',
		'flag' => '<path d="M6.5 21V3.5M6.5 4.5l10.5 3.8-10.5 3.9"/><circle cx="16" cy="18.5" r="2"/>',
		'plus' => '<path d="M12 5v14M5 12h14"/>',
		'close' => '<path d="M6 6l12 12M18 6 6 18"/>',
		'users' => '<circle cx="9" cy="8.5" r="3.2"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0M16 5.6a3 3 0 0 1 0 5.8M17.5 14.2a5.5 5.5 0 0 1 3 4.8"/>',
		'trophy' => '<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 5.5H5a3 3 0 0 0 3 4M16 5.5h3a3 3 0 0 1-3 4M12 13v4M8.5 20h7M9.5 17h5"/>',
		'spark' => '<path d="M12 3.5 13.9 9l5.6 1.9-5.6 1.9L12 18.5l-1.9-5.7-5.6-1.9L10.1 9z"/>',
		'club' => '<path d="M8 3.5 14.8 17.2M14.8 17.2h3.4a1 1 0 0 0 .9-1.3l-.4-1"/><circle cx="7.5" cy="18.5" r="2"/>',
		'instagram' => '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle class="fill" cx="17.2" cy="6.8" r="1.1"/>',
		'facebook' => '<path class="fill" d="M13.5 21v-7.3h2.5l.4-2.9h-2.9V9c0-.8.3-1.4 1.5-1.4h1.5V5.1a19 19 0 0 0-2.2-.1c-2.2 0-3.7 1.3-3.7 3.8v2H8.1v2.9h2.5V21z"/>',
		'tiktok' => '<path class="fill" d="M16.6 3c.4 2.1 1.6 3.4 3.7 3.6v3a7 7 0 0 1-3.7-1.1v6.1a5.6 5.6 0 1 1-4.8-5.5v3.1a2.6 2.6 0 1 0 1.8 2.5V3z"/>',
	);
	}
	if ( ! isset( $paths[ $id ] ) ) { return ''; }
	return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths[ $id ] . '</svg>';
}
function tgs_is_ext( $l ) {
	return ! empty( $l['target'] ) && '_blank' === $l['target'];
}
function tgs_link_attrs( $l ) {
	if ( empty( $l['url'] ) ) { return ''; }
	$a = ' href="' . esc_url( $l['url'] ) . '"';
	if ( tgs_is_ext( $l ) ) { $a .= ' target="_blank" rel="noopener"'; }
	return $a;
}
/** Button from an ACF link. $icon: false | 'auto' (arrow / arrow-ne) | icon name */
function tgs_btn( $l, $classes = 'btn btn--primary', $icon = false ) {
	if ( empty( $l['url'] ) ) { return; }
	if ( 'auto' === $icon ) { $icon = tgs_is_ext( $l ) ? 'arrow-ne' : 'arrow'; }
	echo '<a class="' . esc_attr( $classes ) . '"' . tgs_link_attrs( $l ) . '>' . esc_html( $l['title'] );
	if ( $icon ) { echo ' ' . tgs_icon( $icon ); }
	echo '</a>';
}
/** Image from attachment ID (srcset, width/height & alt come from WordPress) */
function tgs_img( $id, $size = 'large', $attr = array() ) {
	if ( ! $id ) { return ''; }
	return wp_get_attachment_image( $id, $size, false, $attr );
}
function tgs_tel( $b ) {
	// phone_tel khali ho to display number use karo
	$n = ! empty( $b['phone_tel'] ) ? $b['phone_tel'] : ( $b['phone_display'] ?? '' );
	$n = preg_replace( '/[^+\d]/', '', (string) $n );
	return $n ? 'tel:' . $n : '';
}
/* ---------- Tile grid (used by "Play Your Way" and "Events" sections) ---------- */
function tgs_render_tiles( $data, $section_id, $extra_class = 'sec sec--dark tiles-sec' ) {
	if ( empty( $data ) ) { return; }
	$title_id = $section_id . '-title';
	$sizes    = '(min-width: 1000px) 31vw, 47vw';
	?>
	<section class="<?php echo esc_attr( $extra_class ); ?>" id="<?php echo esc_attr( $section_id ); ?>" aria-labelledby="<?php echo esc_attr( $title_id ); ?>">
		<div class="wrap">
			<div class="sec-head">
				<div class="sec-head-main reveal">
					<?php if ( ! empty( $data['eyebrow'] ) ) : ?><p class="eyebrow"><?php echo esc_html( $data['eyebrow'] ); ?></p><?php endif; ?>
					<h2 class="h2" id="<?php echo esc_attr( $title_id ); ?>"><?php echo esc_html( $data['title'] ?? '' ); ?></h2>
					<?php if ( ! empty( $data['lead'] ) ) : ?><p class="lead"><?php echo esc_html( $data['lead'] ); ?></p><?php endif; ?>
				</div>
			</div>
			<?php if ( ! empty( $data['tiles'] ) ) : ?>
			<ul class="vt-grid">
				<?php foreach ( $data['tiles'] as $t ) :
					$l = $t['link'] ?? array();
					if ( empty( $l['url'] ) ) { continue; } ?>
				<li class="vt">
					<?php echo tgs_img( $t['image'], 'large', array( 'sizes' => $sizes, 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
					<div class="vt-body">
						<?php if ( ! empty( $t['kicker'] ) ) : ?>
						<p class="vt-kicker"><?php echo esc_html( $t['kicker'] ); ?> <?php echo tgs_icon( tgs_is_ext( $l ) ? 'arrow-ne' : 'arrow' ); ?></p>
						<?php endif; ?>
						<h3 class="vt-title"><a class="vt-link"<?php echo tgs_link_attrs( $l ); ?>><?php echo esc_html( $t['title'] ); ?></a></h3>
						<?php if ( ! empty( $t['subtitle'] ) ) : ?><p class="vt-sub"><?php echo esc_html( $t['subtitle'] ); ?></p><?php endif; ?>
					</div>
					<?php if ( ! empty( $t['popup'] ) ) : ?>
					<button class="vt-more" type="button" aria-haspopup="dialog" data-tile-more><span class="sr-only">More about <?php echo esc_html( $t['title'] ); ?></span><?php echo tgs_icon( 'plus' ); ?></button>
					<div class="vt-text" hidden><?php echo wp_kses_post( $t['popup'] ); ?></div>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/* ---------- Header menu: Appearance → Menus se ---------- */
add_action( 'after_setup_theme', function () {
	register_nav_menus( array( 'tgs_primary' => 'TGS Main Menu (Header)' ) );
} );

class TGS_Walker_Nav extends Walker_Nav_Menu {
	private $sub_id = '';

	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '<ul class="sub" id="' . esc_attr( $this->sub_id ) . '">';
	}
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul>';
	}
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$title = apply_filters( 'the_title', $item->title, $item->ID );
		$attrs = ' href="' . esc_url( $item->url ) . '"';
		if ( ! empty( $item->target ) ) {
			$attrs .= ' target="' . esc_attr( $item->target ) . '"';
			if ( '_blank' === $item->target ) { $attrs .= ' rel="noopener"'; }
		}

		if ( 0 === $depth && $this->has_children ) {
			// Dropdown wala item
			$this->sub_id = 'sub-' . $item->ID;
			$output .= '<li class="has-sub"><button class="nav-link sub-toggle" type="button" aria-expanded="false" aria-controls="' . esc_attr( $this->sub_id ) . '">'
				. esc_html( $title ) . ' ' . tgs_icon( 'chevron' ) . '</button>';
		} elseif ( 0 === $depth ) {
			// Normal item
			$output .= '<li><a class="nav-link"' . $attrs . '>' . esc_html( $title ) . '</a>';
		} else {
			// Dropdown ke andar ka item (Description = chhota note, jaise PDF)
			$note = ! empty( $item->description ) ? ' <span class="sub-note">' . esc_html( $item->description ) . '</span>' : '';
			$output .= '<li><a' . $attrs . '>' . esc_html( $title ) . $note . '</a>';
		}
	}
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}
}

/* ---------- Footer menus: Appearance → Menus se ---------- */
add_action( 'after_setup_theme', function () {
	register_nav_menus( array(
		'tgs_footer_1' => 'TGS Footer – Column 1 (Quick links)',
		'tgs_footer_2' => 'TGS Footer – Column 2 (Events)',
	) );
} );