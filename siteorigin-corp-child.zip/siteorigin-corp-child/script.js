/* The Golf Sanctuary — home mockup interactions (rev. 30.09 client feedback)
   Everything here is progressive: without JS every tile is still a working link
   and the FAQ still opens (native <details>). */
(() => {
  const d = document;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- header state + floating Book now ---------- */
  const header = d.querySelector('[data-header]');
  const floatBook = d.querySelector('[data-float-book]');
  const onScroll = () => {
    const y = window.scrollY;
    if (header) header.classList.toggle('is-solid', y > 40);
    if (floatBook) floatBook.classList.toggle('is-visible', y > window.innerHeight * 0.55);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- drawer nav ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    const d = document;
    const burger = d.querySelector('[data-burger]');
    const scrim = d.querySelector('[data-nav-scrim]');
    const nav = d.getElementById('site-nav');

    // 1. Mobile Menu Toggle
    function setNav(open) {
        d.body.classList.toggle('nav-open', open);
        d.documentElement.classList.toggle('nav-open', open);
        if (burger) {
            burger.setAttribute('aria-expanded', String(open));
            burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        }
    }

    if (burger) {
        burger.addEventListener('click', function (e) {
            e.preventDefault();
            setNav(!d.body.classList.contains('nav-open'));
        });
    }

    if (scrim) {
        scrim.addEventListener('click', function () {
            setNav(false);
        });
    }

    // 2. Direct Sub-Menu Toggle (Fixed Event Conflict)
    if (nav) {
        const toggleButtons = nav.querySelectorAll('.sub-toggle');

        toggleButtons.forEach(function (toggleBtn) {
            toggleBtn.addEventListener('click', function (e) {
                // Doosre click behaviors ko block karein
                e.preventDefault();
                e.stopPropagation();

                const parentLi = toggleBtn.closest('.has-sub');

                if (parentLi) {
                    const isOpen = parentLi.classList.contains('is-open');

                    // Baaki sabhi open menus ko close karein (Accordion effect)
                    nav.querySelectorAll('.has-sub.is-open').forEach(function (item) {
                        if (item !== parentLi) {
                            item.classList.remove('is-open');
                            const btn = item.querySelector('.sub-toggle');
                            if (btn) btn.setAttribute('aria-expanded', 'false');
                        }
                    });

                    // Current LI me 'is-open' add/remove karein
                    if (isOpen) {
                        parentLi.classList.remove('is-open');
                        toggleBtn.setAttribute('aria-expanded', 'false');
                    } else {
                        parentLi.classList.add('is-open');
                        toggleBtn.setAttribute('aria-expanded', 'true');
                    }
                }
            });
        });

        // Menu ke direct links par click hone par navigation panel close ho
        const normalLinks = nav.querySelectorAll('a:not(.sub-toggle)');
        normalLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                setNav(false);
            });
        });
    }

    // 3. Desktop Resize Reset
    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1360) {
            setNav(false);
        }
    });
});
  /* ---------- sub-menus (click/tap; hover handled in CSS on desktop) ---------- */
  const subs = [...d.querySelectorAll('.has-sub')];
  const closeSubs = (except) => subs.forEach((li) => {
    if (li === except) return;
    li.classList.remove('is-open');
    const b = li.querySelector('.sub-toggle');
    if (b) b.setAttribute('aria-expanded', 'false');
  });
  subs.forEach((li) => {
    const btn = li.querySelector('.sub-toggle');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const open = !li.classList.contains('is-open');
      closeSubs(li);
      li.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  });
  d.addEventListener('click', (e) => { if (!e.target.closest('.has-sub')) closeSubs(); });
  d.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (d.body.classList.contains('nav-open')) { setNav(false); if (burger) burger.focus(); }
    closeSubs();
  });

  /* ---------- tile "+" → dialog (the text itself stays in each tile for SEO) ---------- */
  const dialog = d.getElementById('tile-dialog');
  if (dialog && typeof dialog.showModal === 'function') {
    const media = dialog.querySelector('[data-dialog-media]');
    const kicker = dialog.querySelector('[data-dialog-kicker]');
    const title = dialog.querySelector('[data-dialog-title]');
    const text = dialog.querySelector('[data-dialog-text]');
    const cta = dialog.querySelector('[data-dialog-cta]');
    const closeBtn = dialog.querySelector('[data-dialog-close]');

    d.querySelectorAll('[data-tile-more]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tile = btn.closest('.vt');
        const img = tile.querySelector(':scope > img');
        const link = tile.querySelector('.vt-link');
        const src = tile.querySelector('.vt-text');

        media.innerHTML = '';
        if (img) {
          const pic = new Image();
          pic.src = img.currentSrc || img.src;
          pic.alt = '';
          pic.width = img.width || 800;
          pic.height = img.height || 600;
          media.appendChild(pic);
        }
        kicker.textContent = tile.querySelector('.vt-kicker').textContent.trim();
        title.textContent = link.textContent.trim();
        text.innerHTML = src ? src.innerHTML : '';
        cta.href = link.href;
        cta.textContent = tile.querySelector('.vt-kicker').textContent.trim();
        if (link.target) { cta.target = link.target; cta.rel = 'noopener'; } else { cta.removeAttribute('target'); cta.removeAttribute('rel'); }
        dialog.showModal();
        closeBtn.focus();
      });
    });
    closeBtn.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });   // backdrop click
  }

  /* ---------- reveal on scroll (observer + scroll sweep fallback) ---------- */
  const reveals = [...d.querySelectorAll('.reveal')];
  const reveal = (el) => el.classList.add('is-in');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    reveals.forEach(reveal);
  } else {
    const io = new IntersectionObserver((entries) => entries.forEach((e) => {
      if (e.isIntersecting) { reveal(e.target); io.unobserve(e.target); }
    }), { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
    reveals.forEach((el) => io.observe(el));
    const sweep = () => reveals.forEach((el) => {
      if (!el.classList.contains('is-in') && el.getBoundingClientRect().top < window.innerHeight * 0.97) reveal(el);
    });
    window.addEventListener('scroll', sweep, { passive: true });
    window.addEventListener('load', sweep);
    sweep();
  }
})();
