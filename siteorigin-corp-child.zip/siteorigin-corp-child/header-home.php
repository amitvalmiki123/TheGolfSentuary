<?php
/**
 * Header — The Golf Sanctuary
 * Fields: ACF Options "Site Settings" → tabs Header + Business Details
 */
$h    = tgs_global( 'header' );
$b    = tgs_global( 'business' );
$book = $h['book_link'] ?? array();
$tel  = tgs_tel( $b );
$call = $h['call_label'] ?? 'Call to Book';
$aria_call = $call . ( ! empty( $b['phone_display'] ) ? ': ' . $b['phone_display'] : '' );
?><!doctype html>
<html <?php language_attributes(); ?> class="tgs-home">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0c110e">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<script>document.documentElement.classList.add('js');</script>
<script>document.documentElement.classList.add('js');</script>
<?php wp_head(); ?>
<?php if ( is_front_page() && ! empty( $b ) ) :
	$sameas = array();
	foreach ( (array) ( $b['social'] ?? array() ) as $s ) { if ( ! empty( $s['url'] ) ) { $sameas[] = $s['url']; } }
	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'SportsActivityLocation',
		'@id'         => home_url( '/#venue' ),
		'name'        => $b['name'] ?? get_bloginfo( 'name' ),
		'description' => $b['description'] ?? '',
		'url'         => home_url( '/' ),
		'logo'        => ! empty( $h['logo'] ) ? wp_get_attachment_image_url( $h['logo'], 'full' ) : '',
		'telephone'   => $b['phone_tel'] ?? '',
		'email'       => $b['email'] ?? '',
		'address'     => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $b['street'] ?? '',
			'addressLocality' => $b['locality'] ?? '',
			'addressRegion'   => $b['region'] ?? '',
			'postalCode'      => $b['postcode'] ?? '',
			'addressCountry'  => 'AU',
		),
		'hasMap'      => $b['maps_url'] ?? '',
		'openingHoursSpecification' => array( array(
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ),
			'opens'     => $b['opens'] ?? '07:00',
			'closes'    => $b['closes'] ?? '22:00',
		) ),
		'areaServed'  => array( '@type' => 'City', 'name' => 'Melbourne' ),
		'sameAs'      => $sameas,
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
endif; ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php get_template_part( 'inc/svg-sprite' ); ?>

<a class="skip-link" href="#main">Skip to content</a>

<!-- ============================ HEADER ============================ -->
<header class="site-header" data-header>
	<div class="header-inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — home">
			<?php echo tgs_img( $h['logo'] ?? 0, 'full', array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'eager' ) ); ?>
		</a>

		<nav class="nav" id="site-nav" aria-label="Main">
			<?php
			// Menu: WP Admin → Appearance → Menus → "TGS Main Menu (Header)"
			wp_nav_menu( array(
				'theme_location' => 'tgs_primary',
				'container'      => false,
				'items_wrap'     => '<ul class="nav-list">%3$s</ul>',
				'walker'         => new TGS_Walker_Nav(),
				'depth'          => 2,
				'fallback_cb'    => false,
			) );
			?>
			<div class="nav-foot">
				<?php if ( $tel ) : ?>
				<a class="nav-foot-phone" href="<?php echo esc_attr( $tel ); ?>" title="<?php echo esc_attr( $b['phone_display'] ); ?>" aria-label="<?php echo esc_attr( $aria_call ); ?>"><?php echo tgs_icon( 'phone' ); ?> <?php echo esc_html( $call ); ?></a>
				<?php endif; ?>
				<?php tgs_btn( $book, 'btn btn--primary btn--block', 'arrow-ne' ); ?>

			</div>
		</nav>

		<div class="header-actions">
			<?php if ( $tel ) : ?>
			<a class="header-phone" href="<?php echo esc_attr( $tel ); ?>" title="<?php echo esc_attr( $b['phone_display'] ); ?>" aria-label="<?php echo esc_attr( $aria_call ); ?>"><?php echo tgs_icon( 'phone' ); ?><span><?php echo esc_html( $call ); ?></span></a>
			<?php endif; ?>
			<?php tgs_btn( $book, 'btn btn--primary header-book' ); ?>
			<button class="burger" type="button" aria-controls="site-nav" aria-expanded="false" aria-label="Open menu" data-burger><span></span><span></span><span></span></button>
		</div>
		<div class="nav-scrim" data-nav-scrim aria-hidden="true"></div>
	</div>
</header>