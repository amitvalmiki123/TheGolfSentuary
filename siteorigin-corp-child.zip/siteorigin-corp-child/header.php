<?php
/**
 * Site-wide header (new design) + inner-page banner.
 * Fields : ACF Options "Site Settings" -> Header / Business Details
 * Menu   : Appearance -> Menus -> "TGS Main Menu (Header)"
 */
$h         = tgs_global( 'header' );
$b         = tgs_global( 'business' );
$book      = $h['book_link'] ?? array();
$menu_book = $h['menu_book_link'] ?? array();
if ( empty( $menu_book['url'] ) ) { $menu_book = $book; }   // menu wala field khali ho to header wala link
if ( ! empty( $book['url'] ) )      { $book['target']      = '_blank'; }
if ( ! empty( $menu_book['url'] ) ) { $menu_book['target'] = '_blank'; }
$tel       = tgs_tel( $b );
$call      = $h['call_label'] ?? 'Call to Book';
$aria_call = $call . ( ! empty( $b['phone_display'] ) ? ': ' . $b['phone_display'] : '' );

// Home aur Leagues par inner-page ka banner aur container wrapper nahi chahiye
$tgs_full  = is_page_template( array( 'template-tgs-home.php', 'template-tgs-leagues.php' ) );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<!-- Slick CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
	<script>document.documentElement.classList.add('js');</script>

	<?php wp_head(); ?>

	<?php if ( is_front_page() && ! empty( $b ) ) :
		$sameas = array();
		foreach ( (array) ( $b['social'] ?? array() ) as $s ) { if ( ! empty( $s['url'] ) ) { $sameas[] = $s['url']; } }
		$schema = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'SportsActivityLocation',
			'@id'         => home_url( '/#venue' ),
			'name'        => $b['name'] ?? get_bloginfo( 'name' ),
			'description' => $b['description'] ?? '',
			'url'         => home_url( '/' ),
			'logo'        => ! empty( $h['logo'] ) ? wp_get_attachment_image_url( $h['logo'], 'full' ) : '',
			'telephone'   => $b['phone_tel'] ?? '',
			'email'       => $b['email'] ?? '',
			'address'     => array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => $b['street'] ?? '',
				'addressLocality' => $b['locality'] ?? '',
				'addressRegion'   => $b['region'] ?? '',
				'postalCode'      => $b['postcode'] ?? '',
				'addressCountry'  => 'AU',
			),
			'hasMap'      => $b['maps_url'] ?? '',
			'openingHoursSpecification' => array( array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ),
				'opens'     => $b['opens'] ?? '07:00',
				'closes'    => $b['closes'] ?? '22:00',
			) ),
			'areaServed'  => array( '@type' => 'City', 'name' => 'Melbourne' ),
			'sameAs'      => $sameas,
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	endif; ?>
</head>

<body <?php body_class(); ?>>
<?php if ( function_exists( 'wp_body_open' ) ) { wp_body_open(); }
do_action( 'siteorigin_corp_body_top' );

$tgs_sprite = get_stylesheet_directory() . '/inc/svg-sprite.php';
if ( file_exists( $tgs_sprite ) ) { include $tgs_sprite; }
?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'siteorigin-corp' ); ?></a>

	<?php do_action( 'siteorigin_corp_header_before' ); ?>

	<!-- ============================ HEADER ============================ -->
	<header class="site-header" data-header>
		<div class="header-inner">
			<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — home">
				<?php echo tgs_img( $h['logo'] ?? 0, 'full', array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'eager' ) ); ?>
			</a>

			<nav class="nav" id="site-nav" aria-label="Main">
				<?php
				// Menu: Appearance -> Menus -> "TGS Main Menu (Header)"
				wp_nav_menu( array(
					'theme_location' => 'tgs_primary',
					'container'      => false,
					'items_wrap'     => '<ul class="nav-list">%3$s</ul>',
					'walker'         => new TGS_Walker_Nav(),
					'depth'          => 2,
					'fallback_cb'    => false,
				) );
				?>
				<div class="nav-foot">
					<?php if ( $tel ) : ?>
					<a class="nav-foot-phone" href="<?php echo esc_attr( $tel ); ?>" title="<?php echo esc_attr( $b['phone_display'] ); ?>" aria-label="<?php echo esc_attr( $aria_call ); ?>"><?php echo tgs_icon( 'phone' ); ?> <?php echo esc_html( $call ); ?></a>
					<?php endif; ?>
					<?php tgs_btn( $menu_book, 'btn btn--primary btn--block', 'arrow-ne' ); ?>
				</div>
			</nav>

			<div class="header-actions">
				<?php if ( $tel ) : ?>
				<a class="header-phone" href="<?php echo esc_attr( $tel ); ?>" title="<?php echo esc_attr( $b['phone_display'] ); ?>" aria-label="<?php echo esc_attr( $aria_call ); ?>"><?php echo tgs_icon( 'phone' ); ?><span><?php echo esc_html( $call ); ?></span></a>
				<?php endif; ?>
				<?php tgs_btn( $book, 'btn btn--primary header-book' ); ?>
				<button class="burger" type="button" aria-controls="site-nav" aria-expanded="false" aria-label="Open menu" data-burger><span></span><span></span><span></span></button>
			</div>
			<div class="nav-scrim" data-nav-scrim aria-hidden="true"></div>
		</div>
	</header>

	<?php do_action( 'siteorigin_corp_content_before' ); ?>

<?php if ( !is_home() ) : ?>

<!-- All Pages Banner -->
<!-- <section class="hero" aria-labelledby="hero-title">
	<div class="hero-media">
		<?php
		if ( has_post_thumbnail() ) {
			the_post_thumbnail(
				'full',
				array(
					'class'         => 'hero-img',
					'alt'           => '',
					'loading'       => 'eager',
					'fetchpriority' => 'high',
					'decoding'      => 'async',
					'sizes'         => '100vw',
				)
			);
		} else {
			echo '<img class="hero-img" src="' . esc_url( get_stylesheet_directory_uri() . '/img/banner.jpg' ) . '" alt="" loading="eager" fetchpriority="high" decoding="async" />';
		}
		?>
	</div>

	<div class="hero-scrim" aria-hidden="true"></div>

	<div class="hero-inner">
		<div class="hero-copy">
			<?php
			if ( get_field( 'banner_headling' ) ) {
				echo '<h1 class="hero-title" id="hero-title">' . esc_html( get_field( 'banner_headling' ) ) . '</h1>';
			} else {
				the_title( '<h1 class="hero-title" id="hero-title">', '</h1>' );
			}

			if ( get_field( 'banner_p' ) ) {
				echo '<p class="pra">' . esc_html( get_field( 'banner_p' ) ) . '</p>';
			}

			if ( get_field( 'banner_contents' ) ) : ?>
				<div class="btn-row hero-actions">
					<?php the_field( 'banner_contents' ); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section> -->

<?php endif; ?>


<?php
// Banner sirf ek baar render hoga (duplicate rokne ke liye)
global $tgs_banner_done;

if ( empty( $tgs_banner_done ) ) :
	$tgs_banner_done = true;

	$is_blog  = is_home();
	$page_id  = $is_blog ? get_queried_object_id() : get_the_ID();
	$img_size = $is_blog ? 'feature-large' : 'full';
	$img_attr = array(
		'class'         => 'hero-img',
		'alt'           => '',
		'loading'       => 'eager',
		'fetchpriority' => 'high',
		'decoding'      => 'async',
		'sizes'         => '100vw',
	);

	// Button fields
	$btn1_text = get_field( 'banner_btn1_text' );
	$btn1_link = get_field( 'banner_btn1_link' );
	$btn2_text = get_field( 'banner_btn2_text' );
	$btn2_link = get_field( 'banner_btn2_link' );
	?>

	<!-- Banner -->
	<section class="hero" aria-labelledby="hero-title">
		<div class="hero-media">
			<?php
			if ( has_post_thumbnail( $page_id ) ) {
				echo get_the_post_thumbnail( $page_id, $img_size, $img_attr );
			} else {
				echo '<img class="hero-img" src="' . esc_url( get_stylesheet_directory_uri() . '/img/banner.jpg' ) . '" alt="" loading="eager" fetchpriority="high" decoding="async" />';
			}
			?>
		</div>

		<div class="hero-scrim" aria-hidden="true"></div>

		<div class="hero-inner">
			<div class="hero-copy">
				<?php if ( $is_blog ) : ?>

					<h1 class="hero-title" id="hero-title">Blog</h1>

				<?php else : ?>

					<?php
					if ( get_field( 'banner_headling' ) ) {
						echo '<h1 class="hero-title" id="hero-title">' . esc_html( get_field( 'banner_headling' ) ) . '</h1>';
					} else {
						the_title( '<h1 class="hero-title" id="hero-title">', '</h1>' );
					}

					// Paragraph (buttons se pehle)
					if ( get_field( 'banner_p' ) ) {
						echo '<p class="hero-text">' . esc_html( get_field( 'banner_p' ) ) . '</p>';
					}

					// Buttons (alag-alag fields)
					if ( ( $btn1_text && $btn1_link ) || ( $btn2_text && $btn2_link ) ) : ?>
						<div class="btn-row hero-actions">
								<?php if ( $btn1_text && $btn1_link ) : ?>
									<a class="btn btn--primary btn--lg" href="<?php echo esc_url( $btn1_link ); ?>"><?php echo esc_html( $btn1_text ); ?></a>
								<?php endif; ?>

								<?php if ( $btn2_text && $btn2_link ) : ?>
									<a class="btn btn--ghost btn--lg" href="<?php echo esc_url( $btn2_link ); ?>"><?php echo esc_html( $btn2_text ); ?></a>
								<?php endif; ?>						</div>
					<?php endif; ?>

				<?php endif; ?>
			</div>
		</div>
	</section>

<?php endif; ?>

<?php if ( function_exists( 'tgs_ticker' ) ) { tgs_ticker(); } ?>

	<div id="content" class="site-content">

		<div class="corp-container">

			<?php do_action( 'siteorigin_corp_content_top' ); ?>
