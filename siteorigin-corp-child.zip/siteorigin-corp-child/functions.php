<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'siteorigin-corp-style','siteorigin-corp-style','siteorigin-corp-icons' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

function enqueue_slick_slider_assets() {
    // Enqueue Slick Slider CSS
    wp_enqueue_style('slick-css', get_stylesheet_directory_uri() . '/css/slick.css');
    wp_enqueue_style('slick-theme-css', get_stylesheet_directory_uri() . '/css/slick-theme.css');
    // Enqueue Slick Slider JS
    wp_enqueue_script('slick-js', get_stylesheet_directory_uri() . '/js/slick.min.js', array('jquery'), null, true);
}

add_action('wp_enqueue_scripts', 'enqueue_slick_slider_assets');

add_filter( 'walker_nav_menu_start_el', 'add_arrow', 10, 4 );
function add_arrow( $output, $item, $depth, $args ) {
    // Apply only to 'menu-1' location
    if ( 'menu-1' == $args->theme_location ) {
        if ( in_array( 'menu-item-has-children', $item->classes ) ) {
            $output .= '<span class="reflex-submenu-toggle"></span>';
        }
    }
    return $output;
}

// END ENQUEUE PARENT ACTION


register_sidebar(
        array(
            'name'          => esc_html__( 'Footer', 'storefront' ),
            'id'            => 'footer',
            'description'   => esc_html__( 'Add widgets here.', 'awa' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '',
            'after_title'   => '',
        )
    );

register_sidebar(
        array(
            'name'          => esc_html__( 'Start', 'storefront' ),
            'id'            => 'Start',
            'description'   => esc_html__( 'Add widgets here.', 'awa' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '',
            'after_title'   => '',
        )
    );

register_sidebar(
        array(
            'name'          => esc_html__( 'Top-header', 'storefront' ),
            'id'            => 'Top-header',
            'description'   => esc_html__( 'Add widgets here.', 'awa' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '',
            'after_title'   => '',
        )
    );

function service_columns_slider() {
    ob_start();

    if( have_rows('service_columns', 'option') ): ?>
        
        <div class="service-columns">

            <?php while( have_rows('service_columns', 'option') ): the_row(); ?>

                <div class="column">
                    <div class="slider">

                        <?php while( have_rows('column_slider') ): the_row(); 
                            $img = get_sub_field('img');
                            $heading = get_sub_field('heading');
                            $content = get_sub_field('content');
                        ?>

                            <div class="item">
                                <?php if($img): ?>
                                    <img src="<?php echo esc_url($img['url']); ?>" alt="">
                                <?php endif; ?>

                                <?php if($heading): ?>
                                    <h3><?php echo esc_html($heading); ?></h3>
                                <?php endif; ?>

                                <?php if($content): ?>
                                    <p><?php echo esc_html($content); ?></p>
                                <?php endif; ?>
                            </div>

                        <?php endwhile; ?>

                    </div>
                </div>

            <?php endwhile; ?>

        </div>

    <?php endif;

    return ob_get_clean();
}
add_shortcode('service_columns', 'service_columns_slider');

function membership_terms_shortcode() {
    ob_start();
    ?>

    <div class="terms-box">

      <div class="terms-header">
        <?php the_field('terms_heading', 'option'); ?>
      </div>

      <div class="terms-table">

        <?php if( have_rows('terms_list', 'option') ): ?>
            <?php while( have_rows('terms_list', 'option') ): the_row(); ?>

                <div class="row">
                    <div class="col left">
                        <?php the_sub_field('label'); ?>
                    </div>
                    <div class="col right">
                        <?php the_sub_field('content'); ?>
                    </div>
                </div>

            <?php endwhile; ?>
        <?php endif; ?>

      </div>

    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('membership_terms', 'membership_terms_shortcode');

function change_continue_reading_text($translated_text, $text, $domain) {
    if ($translated_text === 'Continue reading') {
        $translated_text = 'Read More';
    }
    return $translated_text;
}
add_filter('gettext', 'change_continue_reading_text', 20, 3);

function acf_post_title_shortcode($atts) {
    // Get the current post title
    $post_title = get_the_title();
    
    // Get the ACF custom field value (e.g., 'location')
    $location = get_field('location');  // Replace 'location' with your custom field name
    
    // If location is empty, use the post title
    if (empty($location)) {
        return $post_title;
    }

    // Return the formatted string
    return str_replace('Location', $location, $post_title);
}
add_shortcode('acf_post_title', 'acf_post_title_shortcode');

add_filter('acf/format_value', 'run_shortcodes_in_acf_fields', 10, 3);
function run_shortcodes_in_acf_fields($value, $post_id, $field) {
    if (is_string($value)) {
        return do_shortcode($value);
    }
    return $value;
}

//New Home Page
// Helpers + Options page (always load)
require_once get_stylesheet_directory() . '/inc/tgs-helpers.php';
require_once get_stylesheet_directory() . '/inc/tgs-acf-leagues.php';

// ACF field groups — choose ONE method:
// A) PHP registration (these two lines)…
require_once get_stylesheet_directory() . '/inc/tgs-acf-home.php';
require_once get_stylesheet_directory() . '/inc/tgs-acf-global.php';
// B) …or delete the two lines above and copy /acf-json/*.json into your theme's /acf-json folder, then Sync in ACF.

add_action( 'after_setup_theme', function () {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'script', 'style' ) );
} );

add_action( 'wp_enqueue_scripts', function () {
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory();

wp_enqueue_style( 'tgs-fonts', 'https://fonts.googleapis.com/css2?family=Instrument+Sans:wdth,wght@75..100,400..700&family=Outfit:wght@500..700&display=swap', array(), null );

wp_enqueue_script( 'tgs-script', $uri . '/script.js', array(), filemtime( $dir . '/script.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
});

add_action( 'wp_footer', function () {
    $sprite_file = get_template_directory() . '/inc/svg-sprite.php';
    if ( file_exists( $sprite_file ) ) {
        require_once $sprite_file;
    }
} );

/* ---- TGS: saare TrackMan links ko lock karo (koi script inhe badal na sake) ---- */
add_action( 'wp_footer', function () { ?>
<script>
(function () {
    function links() {
        return document.querySelectorAll('a[href*="trackmangolf.com"], a[data-tgs-lock]');
    }
    function snap() {
        var l = links();
        for (var i = 0; i < l.length; i++) {
            if (!l[i].getAttribute('data-tgs-lock')) {
                l[i].setAttribute('data-tgs-lock', l[i].getAttribute('href') || '');
            }
        }
    }
    function restore() {
        var l = links();
        for (var i = 0; i < l.length; i++) {
            var want = l[i].getAttribute('data-tgs-lock');
            if (want && l[i].getAttribute('href') !== want) {
                l[i].setAttribute('href', want);
            }
        }
    }
    snap();                                   // abhi, koi aur script chale usse pehle
    document.addEventListener('DOMContentLoaded', function () { snap(); restore(); });
    window.addEventListener('load', restore);
    setInterval(restore, 600);                // kisi bhi baad wale badlav ko undo karo
    document.addEventListener('mousedown', restore, true);  // click se theek pehle
})();
</script>
<?php }, 1 );


