<?php
/**
 * The template for displaying 404 pages (not found)
 */

get_header(); 
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <section class="error-404 not-found">

            <!-- 404 Image -->
            <div class="default-404-image">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/404.png" alt="404 Image">
            </div>

            <header class="page-header">
                <span class="highlight">404</span>
                <h1 class="page-title">
                    <?php esc_html_e( 'This page could not be found!', 'your-theme-textdomain' ); ?>
                </h1>
            </header>

            <div class="page-content">
                <p class="error-text">
                    <?php esc_html_e( 'We are sorry. But the page you are looking for is not available. Perhaps you can try a new search.', 'your-theme-textdomain' ); ?>
                </p>

                <h2 class="error-404-home">
                    <a href="<?php echo esc_url( home_url('/') ); ?>" class="btn-5">
                        <?php esc_html_e( 'Return to Homepage', 'your-theme-textdomain' ); ?>
                    </a>
                </h2>
            </div>

        </section>

    </main>
</div>

<?php get_footer(); ?>
