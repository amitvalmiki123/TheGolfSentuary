<?php
/**
 * Site-wide footer (new design).
 * Fields : ACF Options "Site Settings" -> Footer / Header / Floating Button / Business Details
 * Menus  : Appearance -> Menus -> "TGS Footer - Column 1 / Column 2"
 */
$h    = tgs_global( 'header' );
$f    = tgs_global( 'footer' );
$b    = tgs_global( 'business' );
$tel  = tgs_tel( $b );
$logo = ! empty( $f['logo'] ) ? $f['logo'] : ( $h['logo'] ?? 0 );
$networks = array( 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'tiktok' => 'TikTok' );

// General header book link as fallback
$book = $h['book_link'] ?? array();

// Mobile bar Book now (alag field ya fallback)
$mobile_book = ! empty( $h['mobile_book_link']['url'] ) ? $h['mobile_book_link'] : $book;
if ( ! empty( $mobile_book['url'] ) ) { $mobile_book['target'] = '_blank'; }

// Floating Book now (alag tab ya fallback)
$fl        = tgs_global( 'floating' );
$fl_link   = ! empty( $fl['link']['url'] ) ? $fl['link'] : $book;
if ( ! empty( $fl_link['url'] ) ) { $fl_link['target'] = '_blank'; }
$fl_show   = $fl['show'] ?? true;
$fl_always = $fl['always'] ?? true;
$fl_icon   = $fl['icon'] ?? 'flag';
?>

    </div><!-- .corp-container -->
  </div><!-- #content -->

  <?php do_action( 'siteorigin_corp_footer_before' ); ?>

  <!-- ============================ FOOTER ============================ -->
  <footer class="site-footer-new">
    <div class="wrap footer-top">
      <div class="footer-brand">
        <?php echo tgs_img( $logo, 'full', array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'lazy' ) ); ?>
        <?php if ( ! empty( $f['tagline'] ) ) : ?><p class="footer-tag"><?php echo esc_html( $f['tagline'] ); ?></p><?php endif; ?>
        <?php if ( ! empty( $f['text'] ) ) : ?><p><?php echo esc_html( $f['text'] ); ?></p><?php endif; ?>
        <?php tgs_btn( $f['cta'] ?? null, 'btn btn--primary' ); ?>
        <?php if ( ! empty( $b['social'] ) ) : ?>
        <ul class="social-row social-row--footer">
          <?php foreach ( $b['social'] as $s ) : if ( empty( $s['url'] ) ) { continue; } ?>
          <li><a class="round-btn" href="<?php echo esc_url( $s['url'] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $networks[ $s['network'] ] ?? 'Social' ); ?>"><?php echo tgs_icon( $s['network'] ); ?></a></li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
      </div>

      <div class="footer-cols">
        <?php foreach ( array( 1 => 'tgs_footer_1', 2 => 'tgs_footer_2' ) as $n => $loc ) : ?>
        <div class="f-col">
          <h2 class="f-head"><?php echo esc_html( $f[ "col{$n}_title" ] ?? '' ); ?></h2>
          <?php
          wp_nav_menu( array(
            'theme_location' => $loc,
            'container'      => false,
            'items_wrap'     => '<ul class="f-links">%3$s</ul>',
            'depth'          => 1,
            'fallback_cb'    => false,
          ) );
          ?>
        </div>
        <?php endforeach; ?>

        <div class="f-col f-col--hello">
          <h2 class="f-head"><?php echo esc_html( $f['hello_title'] ?? 'Say hello' ); ?></h2>
          <address class="f-address">
            <?php if ( ! empty( $b['address_line'] ) ) : ?>
            <a href="<?php echo esc_url( $b['maps_url'] ?? '#' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $b['address_line'] ); ?></a>
            <?php endif; ?>
            <?php if ( $tel ) : ?><a href="<?php echo esc_attr( $tel ); ?>"><?php echo esc_html( $b['phone_display'] ); ?></a><?php endif; ?>
            <?php if ( ! empty( $b['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $b['email'] ) ); ?>"><?php echo esc_html( antispambot( $b['email'] ) ); ?></a><?php endif; ?>
          </address>
          <?php if ( ! empty( $b['hours_text'] ) ) : ?>
          <h2 class="f-head f-head--gap"><?php echo esc_html( $f['hours_title'] ?? 'Opening hours' ); ?></h2>
          <p class="f-hours"><?php echo wp_kses( nl2br( esc_html( $b['hours_text'] ) ), array( 'br' => array() ) ); ?></p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if ( ! empty( $f['location_groups'] ) ) : ?>
    <div class="wrap footer-locs">
      <details class="loc-main">
        <summary><?php echo esc_html( $f['locations_title'] ?? 'Our Service Locations & Services' ); ?> <?php echo tgs_icon( 'chevron' ); ?></summary>
        <div class="loc-groups">
          <?php foreach ( $f['location_groups'] as $g ) :
            $suburbs = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $g['suburbs'] ) ) );
            if ( ! $suburbs ) { continue; } ?>
          <details class="loc-group">
            <summary><?php echo esc_html( $g['heading'] ); ?></summary>
            <ul class="loc-list">
              <?php foreach ( $suburbs as $sub ) : ?>
              <li><a href="<?php echo esc_url( home_url( '/' . trim( $g['slug_prefix'], '/' ) . sanitize_title( $sub ) . '/' ) ); ?>"><?php echo esc_html( trim( $g['label_prefix'] . ' ' . $sub ) ); ?></a></li>
              <?php endforeach; ?>
            </ul>
          </details>
          <?php endforeach; ?>
        </div>
      </details>
    </div>
    <?php endif; ?>

    <div class="wrap footer-bottom">
      <p>
        <?php echo esc_html( str_replace( '{year}', gmdate( 'Y' ), $f['copyright'] ?? '' ) ); ?>
        <?php if ( ! empty( $f['credit_link']['url'] ) ) : ?>
          <?php echo esc_html( $f['credit_prefix'] ?? 'Designed by' ); ?> <a<?php echo tgs_link_attrs( array_merge( $f['credit_link'], array( 'target' => '_blank' ) ) ); ?>><?php echo esc_html( $f['credit_link']['title'] ); ?></a>.
        <?php endif; ?>
      </p>
    </div>
  </footer>
</div><!-- #page -->

<!-- Tile "read more" dialog -->
<dialog class="vt-dialog" id="tile-dialog" aria-labelledby="tile-dialog-title">
  <div class="vt-dialog-card">
    <div class="vt-dialog-media" data-dialog-media></div>
    <div class="vt-dialog-body">
      <p class="eyebrow" data-dialog-kicker></p>
      <h2 class="vt-dialog-title" id="tile-dialog-title" data-dialog-title></h2>
      <div class="vt-dialog-text" data-dialog-text></div>
      <a class="btn btn--primary" href="#main" data-dialog-cta>Find out more</a>
    </div>
    <button class="vt-dialog-close" type="button" aria-label="Close" data-dialog-close><?php echo tgs_icon( 'close' ); ?></button>
  </div>
</dialog>

<!-- Floating Book now (desktop/tablet) -->
<?php if ( $fl_show && ! empty( $fl_link['url'] ) ) : ?>
<a class="float-book<?php echo $fl_always ? ' is-always' : ''; ?>"<?php echo tgs_link_attrs( $fl_link ); ?> data-float-book>
  <span class="float-book-inner"><?php if ( $fl_icon && 'none' !== $fl_icon ) { echo tgs_icon( $fl_icon ); } ?><?php echo esc_html( $fl_link['title'] ?? 'Book Now' ); ?></span>
</a>
<?php endif; ?>

<?php if ( ! empty( $mobile_book['url'] ) || $tel ) : ?>
<!-- Mobile action bar (768px aur chhote) -->
<div class="mbar">
  <?php if ( $tel ) : ?>
  <a class="mbar-call" href="<?php echo esc_attr( $tel ); ?>" aria-label="<?php echo esc_attr( ( $h['call_label'] ?? 'Call' ) . ': ' . ( $b['phone_display'] ?? '' ) ); ?>"><?php echo tgs_icon( 'phone' ); ?><?php echo esc_html( $h['mobile_call_label'] ?? 'Call' ); ?></a>
  <?php endif; ?>
  <?php if ( ! empty( $mobile_book['url'] ) ) : ?>
  <a class="mbar-book"<?php echo tgs_link_attrs( $mobile_book ); ?>><span class="float-book-inner"><?php echo tgs_icon( 'flag' ); ?><?php echo esc_html( $mobile_book['title'] ?? 'Book Now' ); ?></span></a>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php wp_footer(); ?>
<?php do_action( 'siteorigin_corp_footer_after' ); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function(){
    $('.show-more-btn').click(function(){
        var target = $(this).data('target');
        var textMore = $(this).data('text-more');
        var textLess = $(this).data('text-less');

        $(target).slideToggle();

        if($(this).text() == textMore){
            $(this).text(textLess);
        } else {
            $(this).text(textMore);
        }
    });
});
</script>

<script type="text/javascript">
jQuery('.reflex-menu-toggle').click(function () {
    jQuery('.reflex-menu-toggle').toggleClass('is-active');
    jQuery('.menu-header-menu-container').toggleClass('opened');
    jQuery('.menu-header-menu-container').children('li').slideUp();
    jQuery('body').toggleClass('locked');
});

jQuery('.reflex-submenu-toggle').click(function () {
    jQuery(this).toggleClass('rotate');
    jQuery(this).parents('li').children('ul').slideToggle();
    return false;
});
</script>

<script>
jQuery(window).scroll(function(){
  if (jQuery(window).scrollTop() >= 250) {
    jQuery('.site-header').addClass('fixed');
  } else {
    jQuery('.site-header').removeClass('fixed');
  }
});
</script>

<script>
jQuery(document).ready(function() {
  jQuery('[type="email"]').on('input', function() {
    var emailValue = jQuery(this).val();
    jQuery(this).val(emailValue.toLowerCase());
  });
});
</script>

<script>
jQuery(document).ready(function() {
  jQuery("input[type='tel']").bind({
    keydown: function(e) {
      if (e.shiftKey === true ) {
        if (e.which == 9) {
          return true;
        }
        return false;
      }
      if (e.which > 57) {
        if(e.which >=96 && e.which <= 105){
          return true;
        }
        return false;
      }
      if (e.which==32) {
        return false;
      }
      return true;
    }
  });
});
</script>

<script>
document.addEventListener( 'wpcf7mailsent', function( event ) {
    setTimeout( () => {
        location = '/thank-you/';
    }, 3000 );
}, false );
</script>

<script>
document.addEventListener("click", function(){
  setTimeout(function(){
    let activePanel = document.querySelector(".vc_tta-panel.vc_active");
    if(!activePanel) return;

    let classes = ["img-1","img-2","img-3","img-4","img-5"];
    let targetClass = classes.find(cls => activePanel.classList.contains(cls));

    if(targetClass){
      document.querySelectorAll("img.event-img").forEach(img => {
        img.style.display = "none";
      });

      let activeImg = document.querySelector("img.event-img." + targetClass);
      if(activeImg){
        activeImg.style.display = "block";
      }
    }
  }, 300);
});
</script>

<script>
const items = document.querySelectorAll(".event-item");
const images = document.querySelectorAll(".event-img");

items.forEach(item => {
    item.addEventListener("click", function(){
        const id = this.getAttribute("data-id");

        items.forEach(i => i.classList.remove("active"));
        this.classList.add("active");

        images.forEach(img => {
            img.classList.remove("active");
            if(img.getAttribute("data-id") === id){
                img.classList.add("active");
            }
        });
    });
});
</script>

<script>
var _rm = document.querySelector('.read_more');
if (_rm) _rm.addEventListener('click', function(e) {
    e.preventDefault();

    var isExpanded = this.getAttribute('data-expanded') === 'true';
    var hiddenItems = document.querySelectorAll('.hidden-item');

    if (!isExpanded) {
        hiddenItems.forEach(function(item) {
            item.style.display = 'block';
        });
        this.textContent = 'Read Less';
        this.setAttribute('data-expanded', 'true');
    } else {
        hiddenItems.forEach(function(item) {
            item.style.display = 'none';
        });
        this.textContent = 'Read More';
        this.setAttribute('data-expanded', 'false');
    }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('#menu-item-2699 > a, #menu-item-2700 > a').forEach(function (link) {
    link.setAttribute('target', '_blank');
    link.setAttribute('rel', 'noopener noreferrer');
  });
});
</script>

<script type="text/javascript">
/* ===== TGS tile popup ===== */
(function () {
  'use strict';

  var CLOSE_SVG = '<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18"/></svg>';

  function getDialog() {
    var dlg = document.getElementById('tile-dialog');
    if (dlg) { return dlg; }
    dlg = document.createElement('dialog');
    dlg.className = 'vt-dialog';
    dlg.id = 'tile-dialog';
    dlg.setAttribute('aria-labelledby', 'tile-dialog-title');
    dlg.innerHTML =
      '<div class="vt-dialog-card">' +
        '<div class="vt-dialog-media" data-dialog-media></div>' +
        '<div class="vt-dialog-body">' +
          '<p class="eyebrow" data-dialog-kicker></p>' +
          '<h2 class="vt-dialog-title" id="tile-dialog-title" data-dialog-title></h2>' +
          '<div class="vt-dialog-text" data-dialog-text></div>' +
          '<a class="btn btn--primary" href="#main" data-dialog-cta>Find out more</a>' +
        '</div>' +
        '<button class="vt-dialog-close" type="button" aria-label="Close" data-dialog-close>' + CLOSE_SVG + '</button>' +
      '</div>';
    document.body.appendChild(dlg);
    return dlg;
  }

  function closeDialog(dlg) {
    if (dlg.open) { dlg.close(); }
    document.documentElement.classList.remove('dialog-open');
  }

  function openFromTile(btn) {
    var tile = btn.closest('.vt');
    if (!tile) { return; }
    var dlg = getDialog();
    if (dlg.open) { return; }

    var media  = dlg.querySelector('[data-dialog-media]');
    var kicker = dlg.querySelector('[data-dialog-kicker]');
    var title  = dlg.querySelector('[data-dialog-title]');
    var text   = dlg.querySelector('[data-dialog-text]');
    var cta    = dlg.querySelector('[data-dialog-cta]');

    var link   = tile.querySelector('.vt-link');
    var kick   = tile.querySelector('.vt-kicker');
    var hidden = tile.querySelector('.vt-text');
    var visual = tile.querySelector('picture') || tile.querySelector('img');

    if (media) {
      media.innerHTML = '';
      if (visual) {
        var clone = visual.cloneNode(true);
        var imgs = clone.tagName === 'IMG' ? [clone] : clone.querySelectorAll('img');
        for (var i = 0; i < imgs.length; i++) { imgs[i].setAttribute('loading', 'eager'); imgs[i].removeAttribute('fetchpriority'); }
        media.appendChild(clone);
      }
    }
    if (kicker) { kicker.textContent = kick ? kick.textContent.trim() : ''; kicker.hidden = !kick; }
    if (title)  { title.textContent  = link ? link.textContent.trim() : ''; }
    if (text)   { text.innerHTML     = hidden ? hidden.innerHTML : ''; }
    if (cta) {
      if (link) {
        cta.href = link.href;
        if (link.target === '_blank') { cta.target = '_blank'; cta.rel = 'noopener'; }
        else { cta.removeAttribute('target'); cta.removeAttribute('rel'); }
        cta.hidden = false;
      } else { cta.hidden = true; }
    }

    if (typeof dlg.showModal === 'function') { dlg.showModal(); }
    else { dlg.setAttribute('open', ''); }
    document.documentElement.classList.add('dialog-open');
  }

  document.addEventListener('click', function (e) {
    var more = e.target.closest('[data-tile-more]');
    if (more) { e.preventDefault(); openFromTile(more); return; }

    var dlg = document.getElementById('tile-dialog');
    if (!dlg || !dlg.open) { return; }
    if (e.target.closest('[data-dialog-close]') || e.target === dlg) { closeDialog(dlg); }
  });

  document.addEventListener('close', function (e) {
    if (e.target && e.target.id === 'tile-dialog') { document.documentElement.classList.remove('dialog-open'); }
  }, true);
})();
</script>

<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function () {
    const d = document;
    const burger = d.querySelector('[data-burger]');
    const scrim = d.querySelector('[data-nav-scrim]');
    const nav = d.getElementById('site-nav');

    function setNav(open) {
        d.body.classList.toggle('nav-open', open);
        d.documentElement.classList.toggle('nav-open', open);
        if (burger) {
            burger.setAttribute('aria-expanded', String(open));
            burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        }
    }

    if (burger) {
        burger.addEventListener('click', function (e) {
            e.preventDefault();
            setNav(!d.body.classList.contains('nav-open'));
        });
    }

    if (scrim) {
        scrim.addEventListener('click', function () {
            setNav(false);
        });
    }

    if (nav) {
        const toggleButtons = nav.querySelectorAll('.sub-toggle');

        toggleButtons.forEach(function (toggleBtn) {
            toggleBtn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                const parentLi = toggleBtn.closest('.has-sub');

                if (parentLi) {
                    const isOpen = parentLi.classList.contains('is-open');

                    nav.querySelectorAll('.has-sub.is-open').forEach(function (item) {
                        if (item !== parentLi) {
                            item.classList.remove('is-open');
                            const btn = item.querySelector('.sub-toggle');
                            if (btn) btn.setAttribute('aria-expanded', 'false');
                        }
                    });

                    if (isOpen) {
                        parentLi.classList.remove('is-open');
                        toggleBtn.setAttribute('aria-expanded', 'false');
                    } else {
                        parentLi.classList.add('is-open');
                        toggleBtn.setAttribute('aria-expanded', 'true');
                    }
                }
            });
        });

        const normalLinks = nav.querySelectorAll('a:not(.sub-toggle)');
        normalLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                setNav(false);
            });
        });
    }

    window.addEventListener('resize', function () {
        if (window.innerWidth >= 1360) {
            setNav(false);
        }
    });
});
</script>
<script type="text/javascript">
  /* TGS: third-party popup tab hide (works for closed shadow DOM) - All Pages */
(function () {
  var KEY = '3e9da4b';

  function hide() {
    var all = document.body.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      var sig = (el.tagName + ' ' + (el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '')).toLowerCase();
      if (sig.indexOf(KEY) > -1) { el.style.setProperty('display', 'none', 'important'); }
    }
  }

  if (document.body) {
    hide();
    new MutationObserver(hide).observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', function () {
      hide();
      new MutationObserver(hide).observe(document.body, { childList: true, subtree: true });
    });
  }
})();

/* Opening modal ko remove karein aur click event ko unblock karein - All Pages */
document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById('tgs-opening-modal');
    if (modal) {
        modal.remove(); // Direct DOM se modal element delete ho jayega
    }
});
</script>
<script>
document.addEventListener('click', function(e) {
  // Har wo link jisme trackmangolf ka URL hai usko capture karein
  var target = e.target.closest('a[href*="trackmangolf.com"]');
  
  if (target) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation(); // Doosri kisi JS ko ise rokne na de
    
    // Direct new window/tab mein link open karein
    window.open(target.href, '_blank', 'noopener,noreferrer');
  }
}, true); // 'true' event ko capturing phase mein sabse pehle run karega
</script>
</body>
</html>