<?php
/**
 * Template Name: TGS Home
 * Template Post Type: page
 *
 * Fields: ACF group "TGS – Home Page" (acf-json/group_tgs_home_page.json  or  inc/tgs-acf-home.php)
 */

/**
 * Tiles — link khali ho ya "#" ho to kicker/arrow/title-link nahi dikhte.
 */
if ( ! function_exists( 'tgs_render_tiles_v2' ) ) {
	function tgs_render_tiles_v2( $data, $section_id, $extra_class = 'sec sec--dark tiles-sec' ) {
		if ( empty( $data ) ) { return; }
		$title_id = $section_id . '-title';
		$sizes    = '(min-width: 1000px) 31vw, 47vw';
		?>
		<section class="<?php echo esc_attr( $extra_class ); ?>" id="<?php echo esc_attr( $section_id ); ?>" aria-labelledby="<?php echo esc_attr( $title_id ); ?>">
			<div class="wrap">
				<div class="sec-head">
					<div class="sec-head-main reveal">
						<?php if ( ! empty( $data['eyebrow'] ) ) : ?><p class="eyebrow"><?php echo esc_html( $data['eyebrow'] ); ?></p><?php endif; ?>
						<h2 class="h2" id="<?php echo esc_attr( $title_id ); ?>"><?php echo esc_html( $data['title'] ?? '' ); ?></h2>
						<?php if ( ! empty( $data['lead'] ) ) : ?><p class="lead"><?php echo esc_html( $data['lead'] ); ?></p><?php endif; ?>
					</div>
				</div>
				<?php if ( ! empty( $data['tiles'] ) ) : ?>
				<ul class="vt-grid">
					<?php foreach ( $data['tiles'] as $t ) :
						$l        = $t['link'] ?? array();
						$has_link = ! empty( $l['url'] ) && '#' !== trim( $l['url'] );
						?>
					<li class="vt">
						<?php echo tgs_img( $t['image'], 'large', array( 'sizes' => $sizes, 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
						<div class="vt-body">
							<?php if ( $has_link && ! empty( $t['kicker'] ) ) : ?>
							<p class="vt-kicker"><?php echo esc_html( $t['kicker'] ); ?> <?php echo tgs_icon( tgs_is_ext( $l ) ? 'arrow-ne' : 'arrow' ); ?></p>
							<?php endif; ?>
							<h3 class="vt-title">
								<?php if ( $has_link ) : ?>
									<a class="vt-link"<?php echo tgs_link_attrs( $l ); ?>><?php echo esc_html( $t['title'] ); ?></a>
								<?php else : ?>
									<?php echo esc_html( $t['title'] ); ?>
								<?php endif; ?>
							</h3>
							<?php if ( ! empty( $t['subtitle'] ) ) : ?><p class="vt-sub"><?php echo esc_html( $t['subtitle'] ); ?></p><?php endif; ?>
						</div>
						<?php if ( ! empty( $t['popup'] ) ) : ?>
						<button class="vt-more" type="button" aria-haspopup="dialog" data-tile-more><span class="sr-only">More about <?php echo esc_html( $t['title'] ); ?></span><?php echo tgs_icon( 'plus' ); ?></button>
						<div class="vt-text" hidden><?php echo wp_kses_post( $t['popup'] ); ?></div>
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

get_header( 'home' );

$hero   = tgs_field( 'hero' );
$ticker = tgs_field( 'ticker_items' );
$play   = tgs_field( 'play' );
$offer  = tgs_field( 'offer' );
$events = tgs_field( 'events' );
$cta    = tgs_field( 'cta' );
$member = tgs_field( 'member' );
$faq    = tgs_field( 'faq' );
$biz    = tgs_global( 'business' );
?>

<main id="main">

<?php if ( $hero ) : ?>
<!-- ============================ HERO ============================ -->
<section class="hero" aria-labelledby="hero-title">
	<div class="hero-media">
		<?php if ( ! empty( $hero['video'] ) ) : ?>
			<video class="hero-img" autoplay muted loop playsinline preload="metadata" poster="<?php echo esc_url( wp_get_attachment_image_url( $hero['image'], 'full' ) ); ?>">
				<source src="<?php echo esc_url( $hero['video'] ); ?>" type="video/mp4">
			</video>
		<?php else : ?>
			<?php echo tgs_img( $hero['image'], 'full', array( 'class' => 'hero-img', 'sizes' => '100vw', 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?>
		<?php endif; ?>
	</div>
	<div class="hero-scrim" aria-hidden="true"></div>
	<div class="hero-inner">
		<div class="hero-copy">
			<h1 class="hero-title" id="hero-title"><?php echo esc_html( $hero['title'] ); ?></h1>
			<div class="btn-row hero-actions">
				<?php tgs_btn( $hero['primary_button'] ?? null, 'btn btn--primary btn--lg', 'auto' ); ?>
				<?php tgs_btn( $hero['secondary_button'] ?? null, 'btn btn--ghost btn--lg' ); ?>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $ticker ) : ?>
<!-- ============================ TICKER ============================ -->
<div class="ticker" role="region" aria-label="Venue highlights">
	<div class="ticker-track">
		<?php foreach ( array( false, true ) as $dup ) : ?>
		<ul class="ticker-list"<?php echo $dup ? ' aria-hidden="true"' : ''; ?>>
			<?php foreach ( $ticker as $row ) : ?><li><?php echo esc_html( $row['text'] ); ?></li><?php endforeach; ?>
		</ul>
		<?php endforeach; ?>
	</div>
</div>
<?php endif; ?>

<!-- ============================ PLAY YOUR WAY ============================ -->
<?php tgs_render_tiles_v2( $play, 'play' ); ?>

<!-- ============================ EVENTS ============================ -->
<?php tgs_render_tiles_v2( $events, 'events' ); ?>
<?php if ( $offer ) : ?>
<!-- ============================ WHAT WE OFFER ============================ -->
<?php
// Retrieve the ACF group array
$offer = get_field( 'offer' );
?>

<section class="sec sec--paper offer" id="offer" aria-labelledby="offer-title">
    <div class="wrap offer-grid">
        <div class="sec-head-main reveal">
            <?php if ( ! empty( $offer['eyebrow'] ) ) : ?>
                <p class="eyebrow"><?php echo esc_html( $offer['eyebrow'] ); ?></p>
            <?php endif; ?>

            <?php if ( ! empty( $offer['title'] ) ) : ?>
                <h2 class="h2" id="offer-title"><?php echo esc_html( $offer['title'] ); ?></h2>
            <?php endif; ?>

            <?php if ( ! empty( $offer['lead'] ) ) : ?>
                <p class="lead"><?php echo esc_html( $offer['lead'] ); ?></p>
            <?php endif; ?>
        </div>

        <?php if ( ! empty( $offer['perks'] ) && is_array( $offer['perks'] ) ) : ?>
            <ul class="perks">
                <?php foreach ( $offer['perks'] as $p ) :
                    $l     = $p['link'] ?? array();
                    $has   = ! empty( $l['url'] );
                    $tag   = $has ? 'a' : 'div';
                    $icon  = ! empty( $p['icon'] ) ? $p['icon'] : 'spark';

                    // Dynamic attributes setup
                    $attr = '';
                    if ( $has ) {
                        $attr .= ' href="' . esc_url( $l['url'] ) . '"';
                        if ( ! empty( $l['target'] ) ) {
                            $attr .= ' target="' . esc_attr( $l['target'] ) . '"';
                        }
                        if ( isset( $l['target'] ) && '_blank' === $l['target'] ) {
                            $attr .= ' rel="noopener"';
                        }
                    }
                ?>
                <li>
                    <<?php echo $tag; ?> class="perk"<?php echo $attr; ?>>
                        <?php echo tgs_icon( $icon ); ?>
                        <?php if ( ! empty( $p['title'] ) ) : ?>
                            <strong><?php echo esc_html( $p['title'] ); ?></strong>
                        <?php endif; ?>
                        <?php if ( ! empty( $p['text'] ) ) : ?>
                            <span><?php echo esc_html( $p['text'] ); ?></span>
                        <?php endif; ?>
                    </<?php echo $tag; ?>>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>



<?php if ( $cta ) : ?>
<!-- ============================ CTA BAND ============================ -->
<section class="cta-band" aria-labelledby="cta-title">
	<?php echo tgs_img( $cta['background'] ?? 0, 'full', array( 'class' => 'cta-bg', 'sizes' => '100vw', 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
	<div class="wrap cta-inner reveal">
		<h2 class="h2" id="cta-title"><?php echo esc_html( $cta['title'] ); ?></h2>
		<div class="btn-row">
			<?php tgs_btn( $cta['primary_button'] ?? null, 'btn btn--primary btn--lg', 'auto' ); ?>
			<?php tgs_btn( $cta['secondary_button'] ?? null, 'btn btn--ghost btn--lg' ); ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $member ) : ?>
<!-- ============================ BECOME A MEMBER ============================ -->
<section class="member" id="membership" aria-labelledby="member-title">
	<div class="wrap member-grid">
		<div class="member-copy reveal">
			<?php if ( ! empty( $member['eyebrow'] ) ) : ?><p class="eyebrow"><?php echo esc_html( $member['eyebrow'] ); ?></p><?php endif; ?>
			<h2 class="h2" id="member-title"><?php echo esc_html( $member['title'] ); ?></h2>
			<?php if ( ! empty( $member['lead'] ) ) : ?><p class="member-lead"><?php echo esc_html( $member['lead'] ); ?></p><?php endif; ?>
			<?php if ( ! empty( $member['facts'] ) ) : ?>
			<ul class="member-facts">
				<?php foreach ( $member['facts'] as $f ) : ?><li><?php echo esc_html( $f['text'] ); ?></li><?php endforeach; ?>
			</ul>
			<?php endif; ?>
			<div class="btn-row">
				<?php tgs_btn( $member['primary_button'] ?? null, 'btn btn--ink btn--lg', 'auto' ); ?>
				<?php tgs_btn( $member['secondary_button'] ?? null, 'btn btn--outline-ink btn--lg' ); ?>
			</div>
		</div>
		<?php if ( ! empty( $member['image'] ) ) : ?>
		<figure class="member-media reveal">
			<?php echo tgs_img( $member['image'], 'large', array( 'sizes' => '(min-width: 900px) 34vw, 92vw', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
		</figure>
		<?php endif; ?>
	</div>
</section>
<?php endif; ?>

<?php if ( $faq ) : ?>
<!-- ============================ FAQ ============================ -->
<section class="sec sec--paper faq" id="faq" aria-labelledby="faq-title">
	<div class="wrap faq-grid">
		<div class="faq-head reveal">
    <?php if ( ! empty( $faq['eyebrow'] ) ) : ?>
        <p class="eyebrow"><?php echo esc_html( $faq['eyebrow'] ); ?></p>
    <?php endif; ?>

    <h2 class="h2" id="faq-title"><?php echo esc_html( $faq['title'] ); ?></h2>

    <?php if ( ! empty( $faq['lead'] ) ) : ?>
        <p class="lead"><?php echo esc_html( $faq['lead'] ); ?></p>
    <?php endif; ?>

   <div class="faq-cta">
	<?php if ( ! empty( $faq['cta_text'] ) ) : ?><p><?php echo esc_html( $faq['cta_text'] ); ?></p><?php endif; ?>

	<?php
	// Button 2: khali ho to Site Settings ka phone aayega
	$second = $faq['second_button'] ?? array();
	if ( empty( $second['url'] ) && tgs_tel( $biz ) ) {
		$second = array( 'url' => tgs_tel( $biz ), 'title' => $biz['phone_display'], 'target' => '' );
	}

	$faq_buttons = array(
		array( 'link' => $faq['contact_button'] ?? array(), 'class' => 'btn btn--ink' ),
		array( 'link' => $second,                          'class' => 'btn btn--outline-ink' ),
		array( 'link' => $faq['third_button'] ?? array(),   'class' => 'btn btn--outline-ink' ),
	);

	foreach ( $faq_buttons as $i => $b ) :
		$l = $b['link'];
		if ( empty( $l['url'] ) ) { continue; }

		$is_tel = ( 0 === strpos( $l['url'], 'tel:' ) );
		$is_ext = ( ! empty( $l['target'] ) && '_blank' === $l['target'] );
		?>
		<a class="<?php echo esc_attr( $b['class'] ); ?>" href="<?php echo esc_url( $l['url'] ); ?>"<?php echo $is_ext ? ' target="_blank" rel="noopener"' : ''; ?>>
			<?php if ( $is_tel ) : ?>
				<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6.6 3.5h2.6l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5v2.6a2 2 0 0 1-2.2 2A17 17 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2z"/></svg>
				<?php echo esc_html( $l['title'] ); ?>
			<?php else : ?>
				<?php echo esc_html( $l['title'] ); ?>
				<?php if ( 0 === $i ) : /* sirf Button 1 par arrow */ ?>
					<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="<?php echo $is_ext ? 'M7 17 17 7M8.5 7H17v8.5' : 'M4 12h15M13 6l6 6-6 6'; ?>"/></svg>
				<?php endif; ?>
			<?php endif; ?>
		</a>
	<?php endforeach; ?>
</div>
</div>
		<?php if ( ! empty( $faq['items'] ) ) : ?>
		<div class="faq-list">
			<?php foreach ( $faq['items'] as $item ) : ?>
			<details class="faq-item">
				<summary><h3><?php echo esc_html( $item['question'] ); ?></h3><span class="faq-icon" aria-hidden="true"></span></summary>
				<div class="faq-a"><?php echo wp_kses_post( $item['answer'] ); ?></div>
			</details>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>
</section>
<?php
	// FAQPage structured data — built from the same ACF rows
	if ( ! empty( $faq['items'] ) ) {
		$entities = array();
		foreach ( $faq['items'] as $item ) {
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => wp_strip_all_tags( $item['question'] ),
				'acceptedAnswer' => array( '@type' => 'Answer', 'text' => trim( wp_strip_all_tags( $item['answer'] ) ) ),
			);
		}
		echo '<script type="application/ld+json">' . wp_json_encode(
			array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities ),
			JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		) . '</script>' . "\n";
	}
endif; ?>

</main>

<?php get_footer( 'home' );