<?php
/**
 * ACF field group registered in PHP: TGS – Header, Footer & Business
 * Load from functions.php:  require_once get_template_directory() . '/inc/tgs-acf-global.php';
 * (Use this file OR the matching JSON in /acf-json — not both.)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) { return; }
	acf_add_local_field_group( array(
		'key' => 'group_tgs_global_settings',
		'title' => 'TGS – Header, Footer & Business',
		'fields' => array(
			array(
				'type' => 'tab',
				'name' => '',
				'label' => 'Header',
				'placement' => 'top',
				'endpoint' => 0,
				'instructions' => '',
				'required' => 0,
				'key' => 'field_tgs_global_tab_header',
			),
			array(
				'type' => 'group',
				'name' => 'header',
				'label' => 'Header',
				'instructions' => '',
				'required' => 0,
				'sub_fields' => array(
					array(
						'type' => 'image',
						'name' => 'logo',
						'label' => 'Logo',
						'instructions' => 'Used in header (and footer if no separate footer logo is set).',
						'required' => 1,
						'return_format' => 'id',
						'preview_size' => 'medium',
						'library' => 'all',
						'key' => 'field_tgs_global_header_logo',
					),
					array(
						'type' => 'repeater',
						'name' => 'nav',
						'label' => 'Menu',
						'instructions' => '',
						'required' => 0,
						'sub_fields' => array(
							array(
								'type' => 'text',
								'name' => 'label',
								'label' => 'Menu label',
								'instructions' => '',
								'required' => 1,
								'wrapper' => array(
									'width' => '40',
									'class' => '',
									'id' => '',
								),
								'key' => 'field_tgs_global_header_nav_label',
							),
							array(
								'type' => 'link',
								'name' => 'link',
								'label' => 'Link',
								'instructions' => 'Leave empty if this item has a dropdown.',
								'required' => 0,
								'wrapper' => array(
									'width' => '60',
									'class' => '',
									'id' => '',
								),
								'return_format' => 'array',
								'key' => 'field_tgs_global_header_nav_link',
							),
							array(
								'type' => 'repeater',
								'name' => 'sub_items',
								'label' => 'Dropdown items (optional)',
								'instructions' => '',
								'required' => 0,
								'sub_fields' => array(
									array(
										'type' => 'link',
										'name' => 'link',
										'label' => 'Link',
										'instructions' => '',
										'required' => 1,
										'wrapper' => array(
											'width' => '70',
											'class' => '',
											'id' => '',
										),
										'return_format' => 'array',
										'key' => 'field_tgs_global_header_nav_sub_items_link',
									),
									array(
										'type' => 'text',
										'name' => 'note',
										'label' => 'Small note',
										'instructions' => 'e.g. PDF',
										'required' => 0,
										'wrapper' => array(
											'width' => '30',
											'class' => '',
											'id' => '',
										),
										'key' => 'field_tgs_global_header_nav_sub_items_note',
									),
								),
								'layout' => 'block',
								'button_label' => 'Add dropdown item',
								'collapsed' => 'field_tgs_global_header_nav_sub_items_note',
								'min' => 0,
								'max' => 0,
								'key' => 'field_tgs_global_header_nav_sub_items',
							),
						),
						'layout' => 'block',
						'button_label' => 'Add menu item',
						'collapsed' => 'field_tgs_global_header_nav_label',
						'min' => 0,
						'max' => 0,
						'key' => 'field_tgs_global_header_nav',
					),
					array(
						'type' => 'text',
						'name' => 'call_label',
						'label' => 'Call button label',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '33',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Call to Book',
						'key' => 'field_tgs_global_header_call_label',
					),
					array(
						'type' => 'text',
						'name' => 'mobile_call_label',
						'label' => 'Mobile bar call label',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '33',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Call',
						'key' => 'field_tgs_global_header_mobile_call_label',
					),
					array(
						'type' => 'link',
						'name' => 'book_link',
						'label' => 'Book now button',
						'instructions' => 'Also used by the floating Book now button and mobile bar.',
						'required' => 1,
						'wrapper' => array(
							'width' => '33',
							'class' => '',
							'id' => '',
						),
						'return_format' => 'array',
						'key' => 'field_tgs_global_header_book_link',
					),
					array(
	'type' => 'true_false',
	'name' => 'float_show',
	'label' => 'Show floating Book now button',
	'instructions' => '',
	'required' => 0,
	'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
	'default_value' => 1,
	'ui' => 1,
	'ui_on_text' => 'Show',
	'ui_off_text' => 'Hide',
	'key' => 'field_tgs_global_header_float_show',
),
array(
	'type' => 'link',
	'name' => 'float_link',
	'label' => 'Floating button link',
	'instructions' => 'Button ka text link ke title se aata hai. Khali ho to upar wala Book now button use hoga.',
	'required' => 0,
	'wrapper' => array( 'width' => '50', 'class' => '', 'id' => '' ),
	'return_format' => 'array',
	'key' => 'field_tgs_global_header_float_link',
),
array(
	'type' => 'select',
	'name' => 'float_icon',
	'label' => 'Floating button icon',
	'instructions' => '',
	'required' => 0,
	'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
	'choices' => array(
		'flag'     => 'Flag',
		'phone'    => 'Phone',
		'arrow-ne' => 'Arrow',
		'none'     => 'No icon',
	),
	'default_value' => 'flag',
	'return_format' => 'value',
	'allow_null' => 0,
	'multiple' => 0,
	'ui' => 0,
	'key' => 'field_tgs_global_header_float_icon',
),
				),
				'layout' => 'block',
				'key' => 'field_tgs_global_header',
			),
			array(
				'type' => 'tab',
				'name' => '',
				'label' => 'Footer',
				'placement' => 'top',
				'endpoint' => 0,
				'instructions' => '',
				'required' => 0,
				'key' => 'field_tgs_global_tab_footer',
			),
			array(
				'type' => 'group',
				'name' => 'footer',
				'label' => 'Footer',
				'instructions' => '',
				'required' => 0,
				'sub_fields' => array(
					array(
						'type' => 'image',
						'name' => 'logo',
						'label' => 'Footer logo (optional)',
						'instructions' => '',
						'required' => 0,
						'return_format' => 'id',
						'preview_size' => 'medium',
						'library' => 'all',
						'key' => 'field_tgs_global_footer_logo',
					),
					array(
						'type' => 'text',
						'name' => 'tagline',
						'label' => 'Tagline',
						'instructions' => '',
						'required' => 0,
						'default_value' => 'Swing Smarter. Play Better. Experience More.',
						'key' => 'field_tgs_global_footer_tagline',
					),
					array(
						'type' => 'textarea',
						'name' => 'text',
						'label' => 'Short description',
						'instructions' => '',
						'required' => 0,
						'rows' => 3,
						'new_lines' => '',
						'key' => 'field_tgs_global_footer_text',
					),
					array(
						'type' => 'link',
						'name' => 'cta',
						'label' => 'Footer button',
						'instructions' => '',
						'required' => 0,
						'return_format' => 'array',
						'key' => 'field_tgs_global_footer_cta',
					),
					array(
						'type' => 'text',
						'name' => 'col1_title',
						'label' => 'Column 1 title',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Quick links',
						'key' => 'field_tgs_global_footer_col1_title',
					),
					array(
						'type' => 'text',
						'name' => 'col2_title',
						'label' => 'Column 2 title',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Events',
						'key' => 'field_tgs_global_footer_col2_title',
					),
					array(
						'type' => 'repeater',
						'name' => 'col1_links',
						'label' => 'Column 1 links',
						'instructions' => '',
						'required' => 0,
						'sub_fields' => array(
							array(
								'type' => 'link',
								'name' => 'link',
								'label' => 'Link',
								'instructions' => '',
								'required' => 1,
								'return_format' => 'array',
								'key' => 'field_tgs_global_footer_col1_links_link',
							),
						),
						'layout' => 'block',
						'button_label' => 'Add link',
						'collapsed' => '',
						'min' => 0,
						'max' => 0,
						'key' => 'field_tgs_global_footer_col1_links',
					),
					array(
						'type' => 'repeater',
						'name' => 'col2_links',
						'label' => 'Column 2 links',
						'instructions' => '',
						'required' => 0,
						'sub_fields' => array(
							array(
								'type' => 'link',
								'name' => 'link',
								'label' => 'Link',
								'instructions' => '',
								'required' => 1,
								'return_format' => 'array',
								'key' => 'field_tgs_global_footer_col2_links_link',
							),
						),
						'layout' => 'block',
						'button_label' => 'Add link',
						'collapsed' => '',
						'min' => 0,
						'max' => 0,
						'key' => 'field_tgs_global_footer_col2_links',
					),
					array(
						'type' => 'text',
						'name' => 'hello_title',
						'label' => 'Contact column title',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Say hello',
						'key' => 'field_tgs_global_footer_hello_title',
					),
					array(
						'type' => 'text',
						'name' => 'hours_title',
						'label' => 'Hours title',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Opening hours',
						'key' => 'field_tgs_global_footer_hours_title',
					),
					array(
						'type' => 'text',
						'name' => 'locations_title',
						'label' => 'Locations dropdown title',
						'instructions' => '',
						'required' => 0,
						'default_value' => 'Our Service Locations & Services',
						'key' => 'field_tgs_global_footer_locations_title',
					),
					array(
						'type' => 'repeater',
						'name' => 'location_groups',
						'label' => 'Location groups',
						'instructions' => '',
						'required' => 0,
						'sub_fields' => array(
							array(
								'type' => 'text',
								'name' => 'heading',
								'label' => 'Group heading',
								'instructions' => '',
								'required' => 1,
								'wrapper' => array(
									'width' => '33',
									'class' => '',
									'id' => '',
								),
								'default_value' => 'Indoor Golf',
								'key' => 'field_tgs_global_footer_location_groups_heading',
							),
							array(
								'type' => 'text',
								'name' => 'label_prefix',
								'label' => 'Link text prefix',
								'instructions' => 'Link text = prefix + suburb',
								'required' => 0,
								'wrapper' => array(
									'width' => '33',
									'class' => '',
									'id' => '',
								),
								'default_value' => 'Indoor Golf',
								'key' => 'field_tgs_global_footer_location_groups_label_prefix',
							),
							array(
								'type' => 'text',
								'name' => 'slug_prefix',
								'label' => 'URL slug prefix',
								'instructions' => 'URL = site URL + prefix + suburb-slug + /',
								'required' => 0,
								'wrapper' => array(
									'width' => '33',
									'class' => '',
									'id' => '',
								),
								'default_value' => 'indoor-golf-',
								'key' => 'field_tgs_global_footer_location_groups_slug_prefix',
							),
							array(
								'type' => 'textarea',
								'name' => 'suburbs',
								'label' => 'Suburbs (one per line)',
								'instructions' => '',
								'required' => 0,
								'default_value' => 'Armadale
Ashburton
Ashwood
Aspendale
Balwyn
Balwyn North
Bentleigh
Blackburn
Box Hill
Brighton
Burwood
Camberwell
Canterbury
Carnegie
Caulfield
Chadstone
Cheltenham
Clarinda
Clayton
Dingley Village
Doncaster
Doncaster East
Edithvale
Elsternwick
Forest Hill
Glen Waverley
Hampton
Hawthorn
Heatherton
Huntingdale
Kew
Malvern
McKinnon
Melbourne
Mentone
Moorabbin
Mordialloc
Mount Waverley
Mulgrave
Murrumbeena
Notting Hill
Nunawading
Oakleigh
Ormond
Parkdale
Prahran
Surrey Hills
Toorak
Vermont
Wheelers Hill',
								'rows' => 8,
								'new_lines' => '',
								'key' => 'field_tgs_global_footer_location_groups_suburbs',
							),
						),
						'layout' => 'block',
						'button_label' => 'Add location group',
						'collapsed' => 'field_tgs_global_footer_location_groups_heading',
						'min' => 0,
						'max' => 0,
						'key' => 'field_tgs_global_footer_location_groups',
					),
					array(
						'type' => 'text',
						'name' => 'copyright',
						'label' => 'Copyright text',
						'instructions' => '{year} is replaced automatically.',
						'required' => 0,
						'default_value' => 'Copyright {year} © The Golf Sanctuary. All rights reserved.',
						'key' => 'field_tgs_global_footer_copyright',
					),
					array(
						'type' => 'text',
						'name' => 'credit_prefix',
						'label' => 'Credit prefix',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Designed by',
						'key' => 'field_tgs_global_footer_credit_prefix',
					),
					array(
						'type' => 'link',
						'name' => 'credit_link',
						'label' => 'Credit link',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'return_format' => 'array',
						'key' => 'field_tgs_global_footer_credit_link',
					),
				),
				'layout' => 'block',
				'key' => 'field_tgs_global_footer',
			),
array(
	'type' => 'tab',
	'name' => '',
	'label' => 'Floating Button',
	'placement' => 'top',
	'endpoint' => 0,
	'instructions' => '',
	'required' => 0,
	'key' => 'field_tgs_global_tab_floating_button',
),
array(
	'type' => 'group',
	'name' => 'floating',
	'label' => 'Floating Book now button',
	'instructions' => 'Screen ke corner mein fixed rehne wala alag button. Header ke Book now se juda nahi hai.',
	'required' => 0,
	'sub_fields' => array(
		array(
			'type' => 'true_false',
			'name' => 'show',
			'label' => 'Show button',
			'instructions' => '',
			'required' => 0,
			'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
			'default_value' => 1,
			'ui' => 1,
			'ui_on_text' => 'Show',
			'ui_off_text' => 'Hide',
			'key' => 'field_tgs_global_floating_show',
		),
		array(
			'type' => 'true_false',
			'name' => 'always',
			'label' => 'Always visible',
			'instructions' => 'On = scroll ke bina bhi hamesha dikhega.',
			'required' => 0,
			'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
			'default_value' => 1,
			'ui' => 1,
			'ui_on_text' => 'Yes',
			'ui_off_text' => 'No',
			'key' => 'field_tgs_global_floating_always',
		),
		array(
			'type' => 'select',
			'name' => 'icon',
			'label' => 'Icon',
			'instructions' => '',
			'required' => 0,
			'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
			'choices' => array(
				'flag'     => 'Flag',
				'phone'    => 'Phone',
				'arrow-ne' => 'Arrow',
				'none'     => 'No icon',
			),
			'default_value' => 'flag',
			'return_format' => 'value',
			'allow_null' => 0,
			'multiple' => 0,
			'ui' => 0,
			'key' => 'field_tgs_global_floating_icon',
		),
		array(
			'type' => 'link',
			'name' => 'link',
			'label' => 'Button link',
			'instructions' => 'Button ka text link ke title se aata hai (jaise "Book now").',
			'required' => 0,
			'wrapper' => array( 'width' => '25', 'class' => '', 'id' => '' ),
			'return_format' => 'array',
			'key' => 'field_tgs_global_floating_link',
		),
	),
	'layout' => 'block',
	'key' => 'field_tgs_global_floating',
),
			array(
				'type' => 'tab',
				'name' => '',
				'label' => 'Business Details',
				'placement' => 'top',
				'endpoint' => 0,
				'instructions' => '',
				'required' => 0,
				'key' => 'field_tgs_global_tab_business_details',
			),
			array(
				'type' => 'group',
				'name' => 'business',
				'label' => 'Business details (footer, FAQ, schema)',
				'instructions' => '',
				'required' => 0,
				'sub_fields' => array(
					array(
						'type' => 'text',
						'name' => 'name',
						'label' => 'Business name',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'The Golf Sanctuary',
						'key' => 'field_tgs_global_business_name',
					),
					array(
						'type' => 'text',
						'name' => 'email',
						'label' => 'Email',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'key' => 'field_tgs_global_business_email',
					),
					array(
						'type' => 'text',
						'name' => 'phone_display',
						'label' => 'Phone (display)',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => '03 7504 7574',
						'key' => 'field_tgs_global_business_phone_display',
					),
					array(
						'type' => 'text',
						'name' => 'phone_tel',
						'label' => 'Phone (tel link, e.g. +61375047574)',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'key' => 'field_tgs_global_business_phone_tel',
					),
					array(
						'type' => 'textarea',
						'name' => 'description',
						'label' => 'Short description (schema)',
						'instructions' => '',
						'required' => 0,
						'rows' => 3,
						'new_lines' => '',
						'key' => 'field_tgs_global_business_description',
					),
					array(
						'type' => 'text',
						'name' => 'address_line',
						'label' => 'Address (footer display)',
						'instructions' => '',
						'required' => 0,
						'default_value' => '1/1866 Dandenong Rd, Clayton, 3168',
						'key' => 'field_tgs_global_business_address_line',
					),
					array(
						'type' => 'text',
						'name' => 'street',
						'label' => 'Street',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => '1/1866 Dandenong Rd',
						'key' => 'field_tgs_global_business_street',
					),
					array(
						'type' => 'text',
						'name' => 'locality',
						'label' => 'Suburb',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Clayton',
						'key' => 'field_tgs_global_business_locality',
					),
					array(
						'type' => 'text',
						'name' => 'region',
						'label' => 'State',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'VIC',
						'key' => 'field_tgs_global_business_region',
					),
					array(
						'type' => 'text',
						'name' => 'postcode',
						'label' => 'Postcode',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => '3168',
						'key' => 'field_tgs_global_business_postcode',
					),
					array(
						'type' => 'text',
						'name' => 'maps_url',
						'label' => 'Google Maps URL',
						'instructions' => '',
						'required' => 0,
						'key' => 'field_tgs_global_business_maps_url',
					),
					array(
						'type' => 'textarea',
						'name' => 'hours_text',
						'label' => 'Opening hours (footer)',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '50',
							'class' => '',
							'id' => '',
						),
						'default_value' => 'Monday to Sunday:
7am – 10pm',
						'rows' => 2,
						'new_lines' => '',
						'key' => 'field_tgs_global_business_hours_text',
					),
					array(
						'type' => 'text',
						'name' => 'opens',
						'label' => 'Opens (24h)',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => '07:00',
						'key' => 'field_tgs_global_business_opens',
					),
					array(
						'type' => 'text',
						'name' => 'closes',
						'label' => 'Closes (24h)',
						'instructions' => '',
						'required' => 0,
						'wrapper' => array(
							'width' => '25',
							'class' => '',
							'id' => '',
						),
						'default_value' => '22:00',
						'key' => 'field_tgs_global_business_closes',
					),
					array(
						'type' => 'repeater',
						'name' => 'social',
						'label' => 'Social links',
						'instructions' => '',
						'required' => 0,
						'sub_fields' => array(
							array(
								'type' => 'select',
								'name' => 'network',
								'label' => 'Network',
								'instructions' => '',
								'required' => 0,
								'wrapper' => array(
									'width' => '30',
									'class' => '',
									'id' => '',
								),
								'choices' => array(
									'facebook' => 'Facebook',
									'instagram' => 'Instagram',
									'tiktok' => 'TikTok',
								),
								'return_format' => 'value',
								'allow_null' => 0,
								'multiple' => 0,
								'ui' => 0,
								'key' => 'field_tgs_global_business_social_network',
							),
							array(
								'type' => 'url',
								'name' => 'url',
								'label' => 'Profile URL',
								'instructions' => '',
								'required' => 1,
								'wrapper' => array(
									'width' => '70',
									'class' => '',
									'id' => '',
								),
								'key' => 'field_tgs_global_business_social_url',
							),
						),
						'layout' => 'block',
						'button_label' => 'Add social link',
						'collapsed' => 'field_tgs_global_business_social_network',
						'min' => 0,
						'max' => 0,
						'key' => 'field_tgs_global_business_social',
					),
				),
				'layout' => 'block',
				'key' => 'field_tgs_global_business',
			),
		),
		'location' => array(
			array(
				array(
					'param' => 'options_page',
					'operator' => '==',
					'value' => 'tgs-site-settings',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'seamless',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => '',
		'active' => true,
		'description' => '',
		'show_in_rest' => 0,
		'modified' => 1790832410,
	) );
} );


// ---------- Ticker fields (all pages) ----------
add_action( 'acf/init', 'tgs_register_ticker_fields' );

function tgs_register_ticker_fields() {

	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	acf_add_local_field_group( array(
		'key'    => 'group_tgs_ticker',
		'title'  => 'Ticker',
		'fields' => array(
			array(
				'key'          => 'field_tgs_ticker_items',
				'label'        => 'Ticker Items',
				'name'         => 'ticker_items',
				'type'         => 'repeater',
				'layout'       => 'row',
				'button_label' => 'Add item',
				'min'          => 0,
				'sub_fields'   => array(
					array(
						'key'      => 'field_tgs_ticker_text',
						'label'    => 'Text',
						'name'     => 'ticker_text',
						'type'     => 'text',
						'required' => 1,
					),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'page',
				),
			),
		),
		'menu_order' => 2,
		'position'   => 'normal',
		'style'      => 'default',
	) );
}

// ---------- Ticker output ----------
if ( ! function_exists( 'tgs_ticker' ) ) {
	function tgs_ticker() {

		if ( ! function_exists( 'get_field' ) ) {
			return;
		}

		$page_id = is_home() ? get_queried_object_id() : get_the_ID();
		$items   = get_field( 'ticker_items', $page_id );

		if ( empty( $items ) ) {
			return;
		}

		$list = '';
		foreach ( $items as $item ) {
			if ( ! empty( $item['ticker_text'] ) ) {
				$list .= '<li>' . esc_html( $item['ticker_text'] ) . '</li>';
			}
		}

		if ( ! $list ) {
			return;
		}
		?>
		<div class="ticker" role="region" aria-label="Venue highlights">
			<div class="ticker-track">
				<ul class="ticker-list"><?php echo $list; ?></ul>
				<ul class="ticker-list" aria-hidden="true"><?php echo $list; ?></ul>
			</div>
		</div>
		<?php
	}
}